﻿using System.ComponentModel.DataAnnotations;

namespace TypicalTechTools.Models
{
    public class Product
    {
        [Key]
        [Display(Name = "Product Code")]
        public int ProductCode { get; set; }    //Primary key

        [Required]
        [Display(Name = "Product Name")]
        public string ProductName { get; set; } = string.Empty;

        [Display(Name = "Price")]
        [Range(0, 10000)]
        public double ProductPrice { get; set; }

        [Display(Name = "Product Description")]
        [StringLength(maximumLength: 500, MinimumLength = 5, ErrorMessage = "Description must be between 10 and 500 characters")]   //Spicify rules for description
        public string ProductDescription { get; set; } = string.Empty;

        [Display(Name = "Updated Date")]
        public DateTime UpdatedDate { get; set; } = DateTime.Now;


        public virtual ICollection<Comment>? Comments { get; set; } //Specifies the relationship between Products and Comments: Each Product has many comments
    }
}
