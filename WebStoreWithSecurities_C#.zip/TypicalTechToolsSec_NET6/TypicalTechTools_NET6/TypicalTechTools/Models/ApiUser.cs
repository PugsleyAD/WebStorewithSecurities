﻿using TypicalTechTools.Controllers;

namespace TypicalTechTools.Models
{
    public class ApiUser
    {
        public int Id { get; set; }
        public string UserName { get; set; } = string.Empty;
        public string PasswordHash { get; set; } = string.Empty;
        public string Role { get; set; } = "CUSTOMER";
        public string ApiKey { get; set; } = string.Empty;
    }
}
