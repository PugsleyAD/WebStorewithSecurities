﻿//using Microsoft.AspNetCore.Mvc;
//using Microsoft.AspNetCore.Mvc.Filters;
//using TypicalTechTools.Models;
//using TypicalTechTools.Models.Repositories;
//using System.Data;

//namespace TypicalTechTools.Attributes
//{
//    [AttributeUsage(validOn: AttributeTargets.Method | AttributeTargets.Class)]
//    public class ApiKeyAttribute : Attribute, IAsyncActionFilter
//    {
//        //Variable to store the allwed roles for the endpoint
//        private Roles[] allowedRoles;
//        //Property with read only access to the variable
//        public Roles[] AllowedRoles
//        {
//            get { return allowedRoles; }
//        }

//        /// <summary>
//        /// Constructor for our ApiKey attribute which takes the allowed user roles to access the
//        /// associated endpoint or controller.
//        /// </summary>
//        /// <param name="roles">The array of roles allowed to access this action.</param>
//        public ApiKeyAttribute(params Roles[] roles)
//        {
//            allowedRoles = roles;
//        }

//        public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
//        {
//            //Checks if an API kaey was provided
//            if (context.HttpContext.Request.Headers.TryGetValue("apiKey", out var key) == false)
//            {
//                //Send an error code if one was not given with the request.
//                context.Result = new ContentResult
//                {
//                    StatusCode = 401,
//                    Content = "No API Key provided."
//                };
//                return;
//            }
//            //Convert the key from a String Values type to a regular string and trim the curly braces
//            //from the retrieved data.
//            var validKey = key.ToString().Trim('{', '}');
//            //Request the User repository from the services. This is an alternative method to
//            //requesting it through the constructor.
//            var _userRepository = context.HttpContext.RequestServices.GetRequiredService<IAuthenticationRepository>();

//            if (_userRepository.AuthenticateUser(validKey, allowedRoles) == null)
//            {
//                context.Result = new ContentResult
//                {
//                    StatusCode = 403,
//                    Content = "User's API key does not have the required permissions."
//                };

//                return;
//            }

//            await next();
//        }
//    }
//}

