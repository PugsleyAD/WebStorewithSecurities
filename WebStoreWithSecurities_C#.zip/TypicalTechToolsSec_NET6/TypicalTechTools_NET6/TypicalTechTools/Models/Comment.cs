﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Xml.Linq;

namespace TypicalTechTools.Models
{
    public class Comment
    {
        [Display(Name = "Comment Id")]
        [Key]
        public int CommentId { get; set; }  //key

        [Display(Name = "Comment")]
        public string CommentText { get; set; } = string.Empty;


        public string? SessionId { get; set; }


        [Display(Name = "Created Date")]
        public DateTime CreatedDate { get; set; } = DateTime.Now;   //Add a created date to any new comments

        [Display(Name = "Product Code")]
        public int ProductCode { get; set; }    //Foreign key
        
        public virtual Product? Product { get; set; }   //Each Comment has 1 Product


        public string ToCSVString()
        {
            return $"{CommentId},{CommentText},{ProductCode}";  //Pack to a CSV string
        }
    }
}
