﻿using Microsoft.Extensions.Configuration;
using System;
using System.IO;
using System.Security.Cryptography;

namespace TypicalTechTools.Services
{
    public class EncryptionService
    {
        string _secretKey;

        public EncryptionService(IConfiguration config)
        {
            //Request the secret key from our appsettings file.
            _secretKey = config["SecretKey"];
        }

        public byte[] EncryptByteArray(byte[] fileData) 
        {
            //Create an AES algorithm class(This will generate our Initializatin Vector on creation)
            using (var aesAlg = Aes.Create()) 
            {
                //Convert our secret key to a byte array
                aesAlg.Key = System.Text.Encoding.UTF8.GetBytes(_secretKey);
                //Create an encryptor using our key and initialilsation vector(IV) to encryt the data
                ICryptoTransform encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV);
                //Craete new meory stream for holding our file data
                using (var memStream = new MemoryStream()) 
                {
                    //Add the IV to the start of the byte array before we add the file data
                    memStream.Write(aesAlg.IV, 0, 16);
                    //Create acrypto stream which will pass the data back to the memory stream using our encryptor.
                    using (var cryStream = new CryptoStream(memStream, encryptor, CryptoStreamMode.Write))
                    {
                        //Pass our file data through the crypto stream
                        cryStream.Write(fileData,0,fileData.Length);
                        //Finalise the stream's processing before moving on
                        cryStream.FlushFinalBlock();
                        //return the final memory stream data
                        return memStream.ToArray();
                    }
                }
            }
        }

        public byte[] DecryptByteArray(byte[] encryptedData) 
        {
            using (var aesAlg = Aes.Create())
            {
                aesAlg.Key = System.Text.Encoding.UTF8.GetBytes(_secretKey);

                byte[] IV = new byte[16];

                Array.Copy(encryptedData, IV, IV.Length);

                ICryptoTransform decryptor = aesAlg.CreateDecryptor(aesAlg.Key,IV);

                using (var memStream = new MemoryStream()) 
                {
                    using (var cryStream = new CryptoStream(memStream,decryptor,CryptoStreamMode.Write))
                    {
                        cryStream.Write(encryptedData,16,encryptedData.Length - 16);
                        cryStream.FlushFinalBlock();
                        return memStream.ToArray();
                    }
                }
            }
        }
    }
}
