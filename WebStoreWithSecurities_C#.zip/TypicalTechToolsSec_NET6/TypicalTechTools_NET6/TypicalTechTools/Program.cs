using TypicalTechTools.Models;
using TypicalTechTools.Models.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authentication.Cookies;
using Ganss.Xss;
using TypicalTechTools.Services;

var builder = WebApplication.CreateBuilder(args);

//Add services to the container.
builder.Services.AddControllersWithViews();

//Get the connection string from "appsettings"
var connectionString = builder.Configuration.GetConnectionString("Default");

//Add Context Class to the services container so we can access it using the dependency injection system
builder.Services.AddDbContext<TTT_Context>(options => {
    options.UseSqlServer(connectionString);
});

//Adds the repositories to the dependency injection system so they
//can be requested by other classes by using their interface name. 
builder.Services.AddScoped<IProductRepository, ProductRepository>();
builder.Services.AddScoped<ICommentRepository, CommentRepository>();
builder.Services.AddScoped<IAuthenRepository, AuthenRepository>();

//Adds the services for our file uploader and encryption systems.
builder.Services.AddScoped<FileUploaderService>();
builder.Services.AddScoped<EncryptionService>();

builder.Services.AddScoped<HtmlSanitizer>();


builder.Services.AddSession(options =>
{
    //Sets the maximum time the user can be idle between requests before the session expires.
    options.IdleTimeout = TimeSpan.FromMinutes(10);
    //Makes the session cookie only usable through http and cannot be accessed by client side
    //scripts (Javascript)
    options.Cookie.HttpOnly = true;
    //Sets rules about whether the cookie can be used outside the domain it was created.
    options.Cookie.SameSite = SameSiteMode.Strict;
    //Sets rules about whether the cookie must be sent by HTTP or HTTPS or via the same method
    //as the request.
    options.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
    //Checks whether the cookie is required for the site to properly operate.
    options.Cookie.IsEssential = true;
});

//*builder.Services.AddDistributedMemoryCache();
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
                .AddCookie(options =>
                {
                    //Sets the defualt login page for whenever a login redirection is needed
                    options.LoginPath = "/Authen/UserLogin";
                    //Sets the defualt login page for whenever a access denied redirection is needed
                    options.AccessDeniedPath = "/Authen/AccessDenied";
                    //Sets the time before the login expires
                    options.ExpireTimeSpan = TimeSpan.FromMinutes(10);
                    //Resets the expiry if used and has less than half time left.
                    options.SlidingExpiration = true;
                });
//*builder.Services.AddSingleton<CsvParser>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseSession();

app.UseAuthentication();
app.UseAuthorization();

//Custom Middleware(inline)
app.Use(async (context, next) =>
{
    //Adds rules to your HTTP reposnse to tell the browser what sources it is
    //allowed to show content from.
    context.Response.Headers.Add( "Content-Security-Policy", "default-src 'self';" +     //Everything not specified
                                  "img-src 'self';" +  //Images
                                  "script-src 'self';" +  //javascript files
                                  "style-src 'self';" +     //Stylesheets
                                  "form-action 'self';" +   //What resources are allowed to be embedded
                                  "frame-ancestors 'self'");    //Valid sources for HTML form actions
    //Sets whether your users control can be passed from your site to another site.
    context.Response.Headers.Add("Referrer-Policy", "no-referrer");
    //States whether some browsers can sniff (investigate) the MIME types used in responses
    context.Response.Headers.Add("X-Content-Type-Options", "nosniff");
    //Sets whether your site is allowed to be rendered within another webpage.
    context.Response.Headers.Add("X-Frame-Options", "DENY");
    //Requires requests to be done via HTTPS only. The max age sets the time this will be enforced
    //before needing to be set again. On the first connection you will be redirected to HTTPS if you
    //connected by HTTP initially.
    context.Response.Headers.Add("Strict-Transport-Security", "max-age=63072000; includeSubDomains");
    await next(context);
});

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
