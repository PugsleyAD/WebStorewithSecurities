﻿using System.ComponentModel.DataAnnotations;

namespace TypicalTechTools.Models
{
    public class CreateUserDTO
    {
        //[RegularExpression(@"^[a-zA-Z0-9-. ]*$",
        //    ErrorMessage = "A name cannot contain numbers or special characters.")]
        [EmailAddress(ErrorMessage = "Please enter a valid email address.")]
        public string UserName { get; set; } = string.Empty;

        //[RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&_-])[A-Za-z\d@$!%*?&_-]{8,24}$",
        //    ErrorMessage = "String password rules apply.")]
        public string Password { get; set; } = string.Empty;

        //[RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&_-])[A-Za-z\d@$!%*?&_-]{8,24}$",
        //    ErrorMessage = "String password rules apply.")]
        public string PasswordConfirmation { get; set; } = string.Empty;

        public string Role { get; set; } = "CUSTOMER";

        public string ApiKey { get; set; } = string.Empty;
    }
}
