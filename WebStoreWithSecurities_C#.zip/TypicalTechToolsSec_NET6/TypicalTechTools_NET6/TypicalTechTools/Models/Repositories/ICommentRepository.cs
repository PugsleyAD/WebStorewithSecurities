﻿namespace TypicalTechTools.Models.Repositories
{
    public interface ICommentRepository
    {
        List<Comment> GetAllComments(); //View a list of all comments
        List<Comment> GetCommentsByProduct(int code); //View a list of all comments on a product
        Comment GetCommentById(int id); //View a comment
        void AddComment(Comment comment); //Add new comments
        void EditComment(Comment comment); //Allow a user to modify their own recently created comments
        void DeleteComment(Comment comment); //Allow a user to delete their own recently created comments
    }
}
