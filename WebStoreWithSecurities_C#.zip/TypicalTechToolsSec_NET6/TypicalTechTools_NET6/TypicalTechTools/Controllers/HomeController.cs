﻿using Microsoft.AspNetCore.Mvc;
using TypicalTechTools.Services;
using System.Diagnostics;
using TypicalTechTools.Models;

namespace TypicalTechTools.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly FileUploaderService _fileUploader;

        public HomeController(ILogger<HomeController> logger, FileUploaderService uploader)
        {
            _logger = logger;
            _fileUploader = uploader;
        }

        public IActionResult Index()
        {
            return View(); //Create the Home page
        }

        public IActionResult Privacy()
        {
            return View(); //Create the Privacy page
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

    }
}