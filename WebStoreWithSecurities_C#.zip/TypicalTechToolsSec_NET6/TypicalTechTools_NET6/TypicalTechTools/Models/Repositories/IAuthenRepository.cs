﻿namespace TypicalTechTools.Models.Repositories


{
    public interface IAuthenRepository
    {
        ApiUser AuthenticateUser(LoginDTO loginDTO);    //To authenricate a user
        ApiUser CreateUser(CreateUserDTO userDTO);  //To create a user
    }
}