﻿using Microsoft.AspNetCore.Http;

namespace TypicalTechTools.Models.Repositories
{
    public class CommentRepository : ICommentRepository
    {
        private readonly TTT_Context _context;  //Context link to database

        public CommentRepository(TTT_Context context)
        {
            _context = context; //Construct the comment reository
        }
        public void AddComment(Comment comment)
        {
            _context.Comments.Add(comment);
            _context.SaveChanges(); //Add a new comment and save changes in the database
        }

        public void DeleteComment(Comment comment)
        {
            _context.Comments.Remove(comment);
            _context.SaveChanges(); //Delect a comment and save
        }

        public List<Comment> GetAllComments()
        {
            return _context.Comments.ToList();  //View all comments of a product
        }

        public Comment GetCommentById(int id)
        {
            return _context.Comments.Where(c => c.CommentId == id)
                                    .FirstOrDefault() ?? new Comment(); //Look for any comment in the database matches comment id provided
        }

        public List<Comment> GetCommentsByProduct(int code) 
        {

            return _context.Comments.Where(c => c.ProductCode.Equals(code)).ToList();   //View a list of all comments on a product
        }

        public void EditComment(Comment comment)
        {
            _context.Comments.Update(comment);
            _context.SaveChanges(); //Eidt a comment and save
        }

    }
}
