﻿namespace TypicalTechTools.Models.Repositories
{
    public interface IProductRepository
    {
        List<Product> GetAllProducts(); //View all products
        List<Product> SearchProducts(string searchPhrase);  //View products matched search string
        Product GetProductByCode(int productCode);  //View a product
        void CreateProduct(Product product);    //Add new Products
        void EditProduct(Product product);    //Update product details (prices, updated date)

    }
}
