﻿namespace TypicalTechTools.Services
{
    public class FileUploaderService
    {
        string _uploadPath = string.Empty;
        EncryptionService _encryptionService;

        public FileUploaderService(IWebHostEnvironment env, EncryptionService encryptionService)
        {
            _uploadPath = Path.Combine(env.WebRootPath, "Uploads");
            _encryptionService = encryptionService;
        }

        public void SaveFile(IFormFile file)
        {
            //Get the file name from the file and store it.
            string fileName = file.FileName;
            //Declare a new  array to store the file contents once converted to a byte array. 
            byte[] fileContents;

            using (var stream = new MemoryStream())
            {
                //Pass the file contents into the memory stream
                file.CopyTo(stream);
                //Get the file contents back out of the stream as a byte array
                fileContents = stream.ToArray();
            }

            var encryptedFile = _encryptionService.EncryptByteArray(fileContents);

            //Create memory stream for transferring the file data into the file stream.
            using (var dataStream = new MemoryStream(encryptedFile))
            {
                //Combine the file path with the file's name to generate the absolute path.
                var targetFile = Path.Combine(_uploadPath, fileName);
                //Create a file stream to write the file contents to the desired location
                using (var fileStream = new FileStream(targetFile, FileMode.Create))
                {
                    //Write the file from the memopry stream to the file stream which will
                    //save it to the save location.
                    dataStream.WriteTo(fileStream);
                }
            }
        }

        private FileInfo LoadFile(string fileName)
        {
            DirectoryInfo directory = new DirectoryInfo(_uploadPath);

            if (directory.EnumerateFiles().Any(f =>f.Name.Equals(fileName, StringComparison.OrdinalIgnoreCase))) 
            {
                return directory.EnumerateFiles()
                                .Where(f => f.Name.Equals(fileName, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
            }
            return null;
        }

        private byte[] ReadFileIntoMemory(string fileName)
        {
            //Request the file from the Load File method
            var file = LoadFile(fileName);
            //If the file was not found retruyrn null.
            if (file == null)
            {
                return null;
            }
            //Open a memory strea to process the file
            using (var stream = new MemoryStream()) 
            {
                //Open a file stream using the file library to read the file details
                using (var fileStream = File.OpenRead(file.FullName))
                { 
                    //Copy the file from the file locaiton into the memory stream as binary data
                    fileStream.CopyTo(stream);
                    //Return the file data as a byte array from the memory stream.
                    return stream.ToArray();
                }
            }
        }

        public byte[] DownloadFile(string fileName)
        {
            //Requests the selected file as a byte array
            var originalFile = ReadFileIntoMemory(fileName);
            //If the array is null or empty, return null
            if (originalFile == null || originalFile.Length == 0)
            {
                return null;
            }

            var decryptedData = _encryptionService.DecryptByteArray(originalFile);

            //Return the file data contents.
            return decryptedData;
        }
    }
}
