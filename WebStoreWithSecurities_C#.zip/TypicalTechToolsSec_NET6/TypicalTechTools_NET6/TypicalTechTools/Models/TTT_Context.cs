﻿using Microsoft.EntityFrameworkCore;


namespace TypicalTechTools.Models
{
    public class TTT_Context : DbContext
    {

        List<Product> _productList;
        List<Comment> _commentList;

        public DbSet<Product> Products { get; set; }
        public DbSet<Comment> Comments { get; set; }
        public DbSet<ApiUser> ApiUsers { get; set; }

        public TTT_Context(DbContextOptions options) : base(options)
        {
            _productList = new List<Product>(); //Look for products from the database
            _commentList = new List<Comment>(); //Look for comments from the database

            string[] productLines = File.ReadAllLines("./data/Products.csv");   //Load products in the CSV


            foreach(var product in productLines)
            {
                string[] productSections = product.Split(',');  //Use , to split each line from CSV

                Product parsedProduct = new Product //Create each product
                {
                    ProductCode = int.Parse(productSections[0]),
                    ProductName = productSections[1],
                    ProductPrice = double.Parse(productSections[2]),
                    ProductDescription = productSections[3],
                    UpdatedDate = DateTime.Now
                };

                _productList.Add(parsedProduct);    //Add each product to the Plist
            };

            string[] commentLines = File.ReadAllLines("./data/Comments.csv");   //Load comments from the CSV


            foreach (var comment in commentLines)
            {
                string[] commentSections = comment.Split(',');

                Comment parsedComment = new Comment
                {
                    CommentId = int.Parse(commentSections[0]),
                    CommentText = commentSections[1],
                    ProductCode = int.Parse(commentSections[2]),
                    CreatedDate = DateTime.Now,
                };

                _commentList.Add(parsedComment);    //Add each comment to the Clist
            };
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            foreach (var p in _productList) //Add products from CSV to database
            {
                modelBuilder.Entity<Product>().HasData(
                    new Product
                {
                    ProductCode = p.ProductCode,
                    ProductName = p.ProductName,
                    ProductPrice = p.ProductPrice,
                    ProductDescription = p.ProductDescription,
                    UpdatedDate = DateTime.Now
                }
                    );
            }

            foreach (var c in _commentList) //Add comments from CSV to database
            {
                modelBuilder.Entity<Comment>().HasData(
                    new Comment
                    {
                        CommentId = c.CommentId,
                        CommentText = c.CommentText,
                        ProductCode = c.ProductCode,
                        CreatedDate = DateTime.Now
                    }
                    );
            }

            modelBuilder.Entity<ApiUser>().HasData(
              new ApiUser   //Create and Add a user with following details
              {
                  Id = 1,
                  UserName = "admin",
                  PasswordHash = BCrypt.Net.BCrypt.EnhancedHashPassword("admin"),
                  Role = "ADMIN",
                  ApiKey = "d72b10a5-31fa-4251-bb32-ea2d796535ce"
              });

            base.OnModelCreating(modelBuilder);
        }
    }
}

