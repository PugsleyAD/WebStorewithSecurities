﻿using Microsoft.AspNetCore.Http;


namespace TypicalTechTools.Models.Repositories
{
    public class AuthenRepository : IAuthenRepository
    {
        private readonly TTT_Context _context;
        public AuthenRepository(TTT_Context context)
        {
            _context = context;
        }

        public ApiUser AuthenticateUser(LoginDTO loginDTO)
        {
            var userDetails = _context.ApiUsers.Where(u => u.UserName.Equals(loginDTO.UserName))    //Look for a user in the database that matches the provided username
                                               .FirstOrDefault();
            
            if (userDetails == null)
            {
                return null;    //If no user doesn't exists, exit the method and retrun null
            }
           
            if (BCrypt.Net.BCrypt.EnhancedVerify(loginDTO.Password, userDetails.PasswordHash))
            {
                return userDetails;  //Check the user login provided matches the one used to generate the hash
            }
            
            return null;    //If the password was wrong, return null
        }

        public ApiUser CreateUser(CreateUserDTO userDTO)
        {
            var userDetails = _context.ApiUsers.Where(u => u.UserName.Equals(userDTO.UserName))  //Look for a user in the database that matches the provided username
                                               .FirstOrDefault();
            
            if (userDetails != null)
            {
                return null;    //If user exists, exit the method and retrun null
            }
            
            ApiUser user = new ApiUser  //Create a new ApiUser object using the details from the dto
            {
                UserName = userDTO.UserName,
                PasswordHash = BCrypt.Net.BCrypt.EnhancedHashPassword(userDTO.Password),
                Role = userDTO.Role,
                ApiKey = Guid.NewGuid().ToString()
            };

            
            _context.ApiUsers.Add(user);
            _context.SaveChanges();
            return user;    //Add the new user to the database and return the new user
        }

    }
}

