﻿using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;

namespace TypicalTechTools.Models.Repositories

{
    public class ProductRepository : IProductRepository
    {
        private readonly TTT_Context _context;  //Context work with database
        public ProductRepository(TTT_Context context)
        {
            _context = context; //Conutract the product repositroy
        }
        public void CreateProduct(Product product)
        {
            _context.Products.Add(product);
            _context.SaveChanges(); //Add a product and save changes in the database
        }

        public List<Product> GetAllProducts()
        {
            return _context.Products.Include(p => p.Comments).ToList(); //View all products in the database
        }

        public Product GetProductByCode(int code)
        {
            return _context.Products.Where(p => p.ProductCode == code)
                                    .FirstOrDefault() ?? new Product(); //View a product with code matched
        }

        public List<Product> SearchProducts(string searchPhrase)
        {
            return _context.Products.Where(p => p.ProductName.ToLower().Contains(searchPhrase.ToLower())).ToList(); //View products with name matched phrase provided
        }

        public void EditProduct(Product product)
        {
            _context.Products.Update(product);
            _context.SaveChanges(); //Update a product and save
        }

    }
}
