﻿using TypicalTechTools.Models.Repositories;
using Microsoft.AspNetCore.Mvc;
using TypicalTechTools.Models;
using Ganss.Xss;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;


/// <summary>
/// This class implements a Role base login system authenticate and authorise users with the application.
/// The system performs the following:
///   1. Receives username and password from the applicatoin.
///   2. Validates the provided credentials against a data in database.
///   3. If credentials are valid, assigning Roles/Claims.
///   4. Redirects the valid users to the appropriate endpoints or invalid users to default enpoints.
///   
///   5. Handles Login and CreateUser logic.
///   6. It uses AspNetCore Authentication and Authorization system:
///         If a user login successfully, the sysyem will create a Claim identity for the current user with a Claim List.
///         In the Claim List, there is a ClaimType => Role.
///         The Role will be stored in cookies for 10min after users' last intercation with the application.
///         We add annotation to the endpoint controllers to offer access only to users with certain Role ( to "ADMIN" and/or "CUSTOMER" user in this application).
///         If the user does not have permitted Role, he will be redirect to a set url by the routing system.     
/// </summary>

namespace TypicalTechTools.Controllers
{
    public class AuthenController : Controller
    {
        private readonly IAuthenRepository _repository;  //Realize a IAdminRepository
        private readonly HtmlSanitizer _sanitizer;

        public AuthenController(IAuthenRepository repository, HtmlSanitizer htmlSanitizer)
        {
            _repository = repository;   //Construct the AdminController
            _sanitizer = htmlSanitizer;
        }

        public IActionResult UserLogin([FromQuery] string ReturnUrl)
        {
            //Create a LOgin URL object to hold our Return URl 
            LoginDTO loginDTO = new LoginDTO
            {
                ReturnUrl = String.IsNullOrWhiteSpace(ReturnUrl) ? "/Home" : ReturnUrl
            };
            //Pass the return URL to the view and return it to the user.
            return View(loginDTO);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult UserLogin(LoginDTO loginDTO)
        {

            loginDTO.UserName = _sanitizer.Sanitize(loginDTO.UserName);
            loginDTO.Password = _sanitizer.Sanitize(loginDTO.Password);

            var user = _repository.AuthenticateUser(loginDTO);  //Authenticate a user

            if (user == null)
            {
                ViewBag.LoginMessage = "Username or Password incorrect!";   //Authentication fails
                return View();  //Back to login page
            }

            var claims = new List<Claim>        //A series of claims, claims=attributes from Object's properties (Object=AppUser)
            {
                new Claim(ClaimTypes.Name, user.UserName),
                new Claim(ClaimTypes.Role, user.Role)
            };

            //Create a claim identity(user object) for the login
            var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
            //Sets the custom properties for the login where you can potentially override the defaults of the
            //auth cookie setup
            var authProperties = new AuthenticationProperties
            {
                //Lets you override the sliding expiration for this user
                AllowRefresh = true,
                //Lets the cookie persit over multiple requests, not just the next one
                IsPersistent = true,
                //Tells the login where to redirt to once you have finished.
                RedirectUri = loginDTO.ReturnUrl
            };

            //Login the user to the system and store their login details to the auth cookie.
            HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme,
                                    new ClaimsPrincipal(claimsIdentity), authProperties);

            return Redirect(loginDTO.ReturnUrl);

        }

        public IActionResult Logoff()
        {
            HttpContext.SignOutAsync();     //Logs the user out and clears their authentication cookie and session data
            return RedirectToAction("Index", "Home");    //Redirect to Home page
        }


        public IActionResult CreateUser()
        {
            //SetupComboBoxData();
            return View();  //Create page for creating user
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult CreateUser(CreateUserDTO userDTO)
        {
            try
            {
                if (ModelState.IsValid == false)    //model state check
                {
                    ViewBag.CreateUserMessage = "Please fill all required fields!";
                    //SetupComboBoxData();
                    return View(userDTO);
                }

                if (userDTO.Password.Equals(userDTO.PasswordConfirmation) == false)
                {
                    ViewBag.CreateUserMessage = "Password and Password Confirmation do not match!"; //Check whether Passwords matched
                    //SetupComboBoxData();
                    return View(userDTO);
                }

                userDTO.UserName = _sanitizer.Sanitize(userDTO.UserName);
                userDTO.Role = _sanitizer.Sanitize(userDTO.Role);
                userDTO.Password = _sanitizer.Sanitize(userDTO.Password);
                userDTO.PasswordConfirmation = _sanitizer.Sanitize(userDTO.PasswordConfirmation);

                var user = _repository.CreateUser(userDTO); //Create a user

                if (user == null)
                {
                    ViewBag.CreateUserMessage = "UserName already exists!"; //Check whether UserName exists
                    //SetupComboBoxData();
                    return View(userDTO);
                }


                ViewBag.CreateUserMessage = "User Created!";    //Pop up message show user created
                //SetupComboBoxData();
                return View();
            }
            catch
            {
                //SetupComboBoxData();
                return View(userDTO);
            }
        }

        //private void SetupComboBoxData()
        //{

        //    var castedRoleList = new List<SelectListItem>();    //A List stores roles
            
         
        //    SelectListItem admin = new SelectListItem("ADMIN", "ADMIN");
        //    SelectListItem customer = new SelectListItem("CUSTOMER", "CUSTOMER");

        //    if (HttpContext.User.IsInRole("ADMIN") == true)
        //    {
        //        castedRoleList.Add(admin);
        //        castedRoleList.Add(customer);
        //    }
        //    else
        //    {
        //        castedRoleList.Add(customer);
        //    }

        //    ViewBag.Roles = castedRoleList; //Transfer role list to ViewBag


        //}
    }
}
