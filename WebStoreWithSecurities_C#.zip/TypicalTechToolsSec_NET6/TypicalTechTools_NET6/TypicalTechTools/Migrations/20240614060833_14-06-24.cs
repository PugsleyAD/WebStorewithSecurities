﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace TypicalTechTools.Migrations
{
    public partial class _140624 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "ApiUsers",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PasswordHash = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Role = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ApiKey = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ApiUsers", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Products",
                columns: table => new
                {
                    ProductCode = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ProductName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ProductPrice = table.Column<double>(type: "float", nullable: false),
                    ProductDescription = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    UpdatedDate = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Products", x => x.ProductCode);
                });

            migrationBuilder.CreateTable(
                name: "Comments",
                columns: table => new
                {
                    CommentId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CommentText = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SessionId = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ProductCode = table.Column<int>(type: "int", nullable: false),
                    ProductCode1 = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Comments", x => x.CommentId);
                    table.ForeignKey(
                        name: "FK_Comments_Products_ProductCode1",
                        column: x => x.ProductCode1,
                        principalTable: "Products",
                        principalColumn: "ProductCode");
                });

            migrationBuilder.InsertData(
                table: "ApiUsers",
                columns: new[] { "Id", "ApiKey", "PasswordHash", "Role", "UserName" },
                values: new object[] { 1, "d72b10a5-31fa-4251-bb32-ea2d796535ce", "$2a$11$IZQ1pzwHc/.Edf61zOMIh.e/UgO4yvdnIgKWBjBJJAZkgwKujnKIG", "ADMIN", "admin" });

            migrationBuilder.InsertData(
                table: "Comments",
                columns: new[] { "CommentId", "CommentText", "CreatedDate", "ProductCode", "ProductCode1", "SessionId" },
                values: new object[,]
                {
                    { 1, "This is a great product. Highly Recommended.", new DateTime(2024, 6, 14, 16, 8, 32, 676, DateTimeKind.Local).AddTicks(4666), 12345, null, null },
                    { 2, "Not worth the excessive price. Stick with a cheaper generic one.", new DateTime(2024, 6, 14, 16, 8, 32, 676, DateTimeKind.Local).AddTicks(4686), 12350, null, null },
                    { 3, "A great budget buy. As good as some of the expensive alternatives.", new DateTime(2024, 6, 14, 16, 8, 32, 676, DateTimeKind.Local).AddTicks(4708), 12345, null, null },
                    { 4, "Total garbage. Never buying this brand again. ", new DateTime(2024, 6, 14, 16, 8, 32, 676, DateTimeKind.Local).AddTicks(4717), 12347, null, null }
                });

            migrationBuilder.InsertData(
                table: "Products",
                columns: new[] { "ProductCode", "ProductDescription", "ProductName", "ProductPrice", "UpdatedDate" },
                values: new object[,]
                {
                    { 12345, " bluetooth headphones with fair battery life and a 1 month warranty", " Generic Headphones", 84.989999999999995, new DateTime(2024, 6, 14, 16, 8, 32, 676, DateTimeKind.Local).AddTicks(4551) },
                    { 12346, " bluetooth headphones with good battery life and a 6 month warranty", " Expensive Headphones", 149.99000000000001, new DateTime(2024, 6, 14, 16, 8, 32, 676, DateTimeKind.Local).AddTicks(4576) },
                    { 12347, " bluetooth headphones with good battery life and a 12 month warranty", " Name Brand Headphones", 199.99000000000001, new DateTime(2024, 6, 14, 16, 8, 32, 676, DateTimeKind.Local).AddTicks(4596) },
                    { 12348, " simple bluetooth pointing device", " Generic Wireless Mouse", 39.990000000000002, new DateTime(2024, 6, 14, 16, 8, 32, 676, DateTimeKind.Local).AddTicks(4611) },
                    { 12349, " mouse and keyboard wired combination", " Logitach Mouse and Keyboard", 73.989999999999995, new DateTime(2024, 6, 14, 16, 8, 32, 676, DateTimeKind.Local).AddTicks(4626) },
                    { 12350, " quality wireless mouse", " Logitach Wireless Mouse", 149.99000000000001, new DateTime(2024, 6, 14, 16, 8, 32, 676, DateTimeKind.Local).AddTicks(4645) }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Comments_ProductCode1",
                table: "Comments",
                column: "ProductCode1");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ApiUsers");

            migrationBuilder.DropTable(
                name: "Comments");

            migrationBuilder.DropTable(
                name: "Products");
        }
    }
}
