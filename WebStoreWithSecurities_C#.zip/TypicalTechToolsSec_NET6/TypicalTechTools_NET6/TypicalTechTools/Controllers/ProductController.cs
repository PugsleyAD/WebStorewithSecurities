﻿using TypicalTechTools.Models;
using TypicalTechTools.Models.Repositories;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Ganss.Xss;

namespace TypicalTools.Controllers
{
    public class ProductController : Controller
    {
        private readonly IProductRepository _productRepository;
        private readonly HtmlSanitizer _sanitizer;

        public ProductController(IProductRepository proRepo, HtmlSanitizer htmlSanitizer)
        {
            _productRepository = proRepo;
            _sanitizer = htmlSanitizer;
        }

        // GET: Product/Index
        public ActionResult Index()
        {
            return View(_productRepository.GetAllProducts());
        }

        public ActionResult ShowSearchResults(string searchPhrase)
        {
            //The following statement is a terniary operator to check if a search value was provided.
            //A terniary operator takes an expression and follows it with a question mark. After the
            //question mark you provide 2 potential values to be returned. If the expression is true it will
            //return the 1st value, otherwise it will return the 2nd value. This is a shortcut way for writing
            //as if else where each section only sets or returns a single value.
            searchPhrase = (string.IsNullOrWhiteSpace(searchPhrase)) ? "" : searchPhrase;

           
            HttpContext.Session.SetString("LastProductSearch", searchPhrase);   //Store the last search value in the session data (key as "LastProductSearch")
            
            var products = _productRepository.SearchProducts(searchPhrase); //Retrieve any matching products from the repository and passes them to the index view
            return View("Index", products); //Create page of all products
        }

        // GET: ProductController/Details/
        public ActionResult Details(int id)     //why has to be 'id'? because it is usting route/URL "id"
        {
            return View(_productRepository.GetProductByCode(id));   //Create detail page of a product
        }

        // GET: ProductController/Create
       [Authorize(Roles = "ADMIN")]
        public ActionResult CreateProduct()
        {
            return View();
        }

        // POST: ProductController/Create
        [HttpPost]
        [Authorize(Roles = "ADMIN")]
        [ValidateAntiForgeryToken]
        public ActionResult CreateProduct(Product product)
        {

            try
            {
                if (ModelState.IsValid == false)
                {
                    return View(product);
                }

                product.ProductName = _sanitizer.Sanitize(product.ProductName);
                product.ProductDescription = _sanitizer.Sanitize(product.ProductDescription);

                _productRepository.CreateProduct(product);
                return RedirectToAction("Index", "Product");
            }
            catch
            {
                return View(product);
            }
        }

        // GET: ProductController/Edit/
        [Authorize(Roles = "ADMIN")]
        public ActionResult EditProduct(int id)
        {

            var product = _productRepository.GetProductByCode(id);

            HttpContext.Session.SetString("NamePicked", product.ProductName.ToString());    //Set "NamePicked" key with value ProductName
            HttpContext.Session.SetString("DescPicked", product.ProductDescription.ToString()); //Set "DescPicked key with value Description

            return View(product);   //Create eidt page of a product
        }

        // POST: AuthorController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "ADMIN")]
        public ActionResult EditProduct(Product product)
        {
            try
            {
                if (ModelState.IsValid == false)    //Check whether data received match data model requirements
                {
                    return View(product);
                }

                product.ProductName = _sanitizer.Sanitize(product.ProductName);
                product.ProductDescription = _sanitizer.Sanitize(product.ProductDescription);

                _productRepository.EditProduct(product);
                return RedirectToAction(nameof(Index)); //Redirect to edit page of a product
            }
            catch
            {
                return View(product);
            }
        }
    }
}
