﻿using System.ComponentModel.DataAnnotations;

namespace TypicalTechTools.Models
{
    public class LoginDTO
    {
        //[RegularExpression(@"^[a-zA-Z0-9-. ]*$",
           //ErrorMessage = "A name cannot contain numbers or special characters.")]
        public string UserName { get; set; } = string.Empty;
        //[RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&_-])[A-Za-z\d@$!%*?&_-]{8,12}$",
            //ErrorMessage = "String password rules apply.")]
        public string Password { get; set; } = string.Empty;

        public string ReturnUrl { get; set; } = string.Empty;

    }
}
