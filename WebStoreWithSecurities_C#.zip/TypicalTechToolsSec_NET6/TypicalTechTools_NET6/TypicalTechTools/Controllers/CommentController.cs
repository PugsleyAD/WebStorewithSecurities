﻿using TypicalTechTools.Models.Repositories;
using TypicalTechTools.Models;
using Microsoft.AspNetCore.Mvc;
using Ganss.Xss;
using Microsoft.AspNetCore.Authorization;
using System.Data;

namespace TypicalTechTools.Controllers
{

    public class CommentController : Controller
    {
        private readonly ICommentRepository _commentRepository; //Realize a ICommentRepository
        private readonly IProductRepository _productRepository; //Realize a IProductRepository
        private readonly HtmlSanitizer _sanitizer;

        public CommentController(ICommentRepository comRepo, IProductRepository proRepo, HtmlSanitizer htmlSanitizer)
        {
            _commentRepository = comRepo;
            _productRepository = proRepo;   ////Construct the CommentController
            _sanitizer = htmlSanitizer;
        }


        [Authorize(Roles = "ADMIN, CUSTOMER")]
        public ActionResult EditComment(int id)
        {
            //string authenticated = HttpContext.Session.GetString("Authenticated") ?? "false"; //Store authentication status to a string

            var sessionId = _commentRepository.GetCommentById(id).SessionId;    //Store seesionId of the current comment

            if (!HttpContext.User.IsInRole("ADMIN") && !sessionId.Equals(HttpContext.Session.Id))
            {
                return RedirectToAction("Index", "Home");   //Redirect to Home page with a non-ADMIN role
            }
            return View(_commentRepository.GetCommentById(id)); //Create EditComment page with ADMIN role
        }

        // POST: AuthorController/Edit/
        [Authorize(Roles = "ADMIN, CUSTOMER")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult EditComment(Comment comment)
        {
            try
            {
                if (ModelState.IsValid == false)
                {
                    return View(comment);
                }

                HttpContext.Session.SetString("SessionId", HttpContext.Session.Id); //Set the session Id
                
                comment.SessionId = HttpContext.Session.Id; //Pass the session Id to the comment record

                int id;
                int.TryParse(HttpContext.Session.GetString("CodePicked"), out id); //Set id value to tell which comment is picked

                comment.CommentText = _sanitizer.Sanitize(comment.CommentText);

                _commentRepository.EditComment(comment);
                return RedirectToAction(nameof(CommentsOfOne), new { id = id });    //Redirect to page of the picked comment
            }
            catch
            {
                return View(comment);
            }
        }

        // GET: BookController/Delete/
        [Authorize(Roles = "ADMIN, CUSTOMER")]
        public ActionResult DeleteComment(int id)
        {
            //string authenticated = HttpContext.Session.GetString("Authenticated") ?? "false";   //Check autentication status
            var sessionId = _commentRepository.GetCommentById(id).SessionId;    //Get session Id of a comment
            if (!HttpContext.User.IsInRole("ADMIN") && !sessionId.Equals(HttpContext.Session.Id))
            {
                return RedirectToAction("Index", "Home");   //If user roles is not ADMIN, redirect to Home page
            }

            var comment = _commentRepository.GetCommentById(id); //Get the comment wish to delect
            return View(comment);
        }

        // POST: BookController/Delete/
        [Authorize(Roles = "ADMIN, CUSTOMER")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteComment(Comment comment)
        {
            try
            {
                int id;
                int.TryParse(HttpContext.Session.GetString("CodePicked"), out id);  //Set id value to tell which comment is picked

                _commentRepository.DeleteComment(comment);
                return RedirectToAction(nameof(CommentsOfOne), new {id = id}); //Redirect to page of all comments of a product
            }
            catch
            {
                return View(comment);
            }
        }

        //GET: Comments of one Product
        public ActionResult CommentsOfOne(int id)     //View all comments of a product    /can only use id
        {
            var product = _productRepository.GetProductByCode(id);

            HttpContext.Session.SetString("CodePicked", product.ProductCode.ToString());
            HttpContext.Session.SetString("NamePicked", product.ProductName.ToString());

            return View(_commentRepository.GetCommentsByProduct(id));
        }


        [Authorize(Roles = "ADMIN, CUSTOMER")]
        public ActionResult AddComment()
        {
            return View();
        }

        // POST: CommentController/AddComment
        [Authorize(Roles = "ADMIN, CUSTOMER")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AddComment(Comment comment)
        {
            try
            {
                if (ModelState.IsValid == false)
                {
                    return View(comment);
                }

                HttpContext.Session.SetString("SessionId", HttpContext.Session.Id);
                
                comment.SessionId = HttpContext.Session.Id; //Pass the session Id to the comment record

                int id;
                int.TryParse(HttpContext.Session.GetString("CodePicked"), out id);  //Use id to tell which product the comment belong to

                comment.CommentText = _sanitizer.Sanitize(comment.CommentText);

                _commentRepository.AddComment(comment);
                return RedirectToAction(nameof(CommentsOfOne), new { id = id }); //Redirect to comment list page of a product
            }
            catch
            {
                return View(comment);
            }
        }
    }
}
